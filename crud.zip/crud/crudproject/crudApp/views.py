from django.shortcuts import render,HttpResponseRedirect

# Create your views here.
from .forms import StudentRegistration
from .models import Students

# this function will add new iteam and show all iteam
def add_show(request):
    if request.method =='POST':
        fm=StudentRegistration(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            em = fm.cleaned_data['email']
            pw = fm.cleaned_data['password']
            ad = fm.cleaned_data['address']
            reg = Students(name=nm, email=em, password=pw, address=ad)  # store in database table(User)
            reg.save()
            fm=StudentRegistration()  #...clear data on server page
    else:
        fm=StudentRegistration()
    stud=Students.objects.all()    # show all data
    return render(request,'crudApp/addandshow.html',{'form':fm,'stu':stud})


# this function will delete

def delete_data(request,id):
    if request.method=='POST':
        pi=Students.objects.get(pk=id)  #---pk=primery key id
        pi.delete()
        return HttpResponseRedirect('/')


#this function will update data
def update_data(request,id):
    if request.method=='POST':
        pi=Students.objects.get(pk=id)
        fm=StudentRegistration(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi = Students.objects.get(pk=id)
        fm = StudentRegistration(instance=pi)
    return render(request,'crudApp/updatestudent.html' ,{'form':fm} )